
public class Node {
	public Addr addr;
	public Node nextNode;
	
}
