package com.test.myapp.aspectLog;

import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import org.aspectj.lang.ProceedingJoinPoint;


@Component
@Aspect
public class HelloLog {
	
	@Pointcut(value = "execution(* com.test..*.sayHello(..))")
	private void helloPointcut() {}
	

	@Before("helloPointcut()")
	public static void log() {
		System.out.println(">>>LOG<<< : " + new java.util.Date());
	}
	
	
	@Around("helloPointcut()")
	public Object trace(ProceedingJoinPoint joinPoint) throws Throwable{		
		Object result = null;
		try {
			result = joinPoint.proceed();
		}catch(Exception e) {
			System.out.println("Exception");
		}finally {
			System.out.println("finally 실행");
		}
		
		return result;
	}
}
