package com.test.myapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;

import com.test.myapp.service.IHelloService;

@Controller
public class HelloController {
	/*Annotation 주입*/
	@Autowired
	@Qualifier("helloService")
	IHelloService helloService;

	/*생성자 주입*/
//	public HelloController(IHelloService helloService) {
//		this.helloService = helloService;
//	}
	
//	/*세터 주입*/
//	public void setHelloService(IHelloService helloService) {
//		this.helloService = helloService;
//	}

	public void hello(String name) {
		System.out.println("HelloController : " + helloService.sayHello());
	}
}
