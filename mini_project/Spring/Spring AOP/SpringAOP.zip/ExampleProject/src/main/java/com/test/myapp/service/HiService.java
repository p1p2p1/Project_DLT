package com.test.myapp.service;

import org.springframework.stereotype.Service;

@Service
public class HiService implements IHelloService{
	public String sayHello() {
		System.out.println("안녕하세요! Hi");
		return "hi";
	}
}
