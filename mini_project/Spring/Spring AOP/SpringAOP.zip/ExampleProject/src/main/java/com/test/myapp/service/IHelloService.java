package com.test.myapp.service;

public interface IHelloService {
	public String sayHello();
}
