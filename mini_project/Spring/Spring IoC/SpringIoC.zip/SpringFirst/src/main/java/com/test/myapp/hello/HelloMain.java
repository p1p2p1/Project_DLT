package com.test.myapp.hello;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.test.myapp.hello.controller.HelloController;


public class HelloMain {
	public static void main(String[] args) {
		//스프링 기능을 사용하는 경우
		//IoC로 인해서 xml 파일에서 빈을 생성하기 때문
		//스프링에서 DI를 지원하는건 아닌가?
		//지원한다.
		AbstractApplicationContext context = new GenericXmlApplicationContext("application-config.xml");
		HelloController controller = context.getBean("helloController", HelloController.class);
		
		controller.hello("안녕");
		context.close();
	}
}
