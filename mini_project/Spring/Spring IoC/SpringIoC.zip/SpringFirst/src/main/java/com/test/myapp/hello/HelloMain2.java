package com.test.myapp.hello;

import com.test.myapp.hello.controller.HelloController;
import com.test.myapp.hello.service.HelloService;
import com.test.myapp.hello.service.IHelloService;

public class HelloMain2 {
	//스프링 안썼을 때 DI
	public static void main(String[] args) {
		//만약 의존성 주입이 없다면
	/*
		HelloController controller = new HelloController();
		controller.hello("이름");
	*/
		//의존성 주입이 없다면 HelloController로 들어가서 구현 클래스에 대한
		//선언을 초기화해야 한다.
		
		//의존성 주입
		IHelloService service = new HelloService();
		
		//의존성 주입으로 인해 service에 대한 구현 클래스만 바꿔줘도 간단히 바꿀 수 있다.
		HelloController controller = new HelloController(service);
		controller.hello("이름");
	}
}
