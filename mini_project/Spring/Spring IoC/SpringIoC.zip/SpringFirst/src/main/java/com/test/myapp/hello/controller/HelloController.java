package com.test.myapp.hello.controller;

import com.test.myapp.hello.service.IHelloService;

public class HelloController{
	//의존성 주입 안할 경우
//	IHelloService helloService = new HelloService();
	
	//의존성 주입
	IHelloService helloService;
	
	
	/*생성자 주입*/
	public HelloController(IHelloService helloService) {
		this.helloService = helloService;
	}
	
	public void hello(String name) {
		System.out.println("HelloController : " + helloService.sayHello(name));
	}
}
