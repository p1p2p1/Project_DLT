package com.test.myapp.hello.service;

public class HiService implements IHelloService{
	public String sayHello(String name) {
		System.out.println("HiService2.sayHello 메소드 실행");
		String message = "Hi~~~" + name;
		return message;
	}
}
