package com.test.myapp.hello.service;

public interface IHelloService {
	String sayHello(String name);
}
