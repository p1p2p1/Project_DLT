package com.test.myapp.member;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class CollectionTest {	
	private static final Logger logger = LoggerFactory.getLogger(CollectionTest.class);
	public static void main(String[] args) {
		AbstractApplicationContext context = new GenericXmlApplicationContext("application-config.xml");
		Customer cust = context.getBean(Customer.class);
//		System.out.println(cust.getMaps().get("Key3"));
//		System.out.println(cust.getLists().get(1));
//		System.out.println(cust.getProps().get("webmaster"));
		
		logger.info("{}", cust.getMaps().get("Key3"));
		logger.info("{}", cust.getLists().get(1));
		logger.info("{}", cust.getProps().get("webmaster"));
		
		context.close();
//		logger.info("{}",cust.getLists().get(1));
	}
}
