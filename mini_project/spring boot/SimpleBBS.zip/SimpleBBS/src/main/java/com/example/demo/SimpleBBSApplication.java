package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleBBSApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleBBSApplication.class, args);
	}

}
