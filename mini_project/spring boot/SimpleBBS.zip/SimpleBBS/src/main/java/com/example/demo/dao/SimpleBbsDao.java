package com.example.demo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.demo.dto.SimpleBbsDto;

@Repository
public class SimpleBbsDao implements ISimpleBbsDao{
	@Autowired
	JdbcTemplate template;

	@Override
	public List<SimpleBbsDto> listDao() {
		System.out.println("listDao()");
		
		String query = "SELECT * FROM simple_bbs ORDER BY id DESC";
		List<SimpleBbsDto> dtos = template.query(
				query, new BeanPropertyRowMapper<>(SimpleBbsDto.class));
		return dtos;
	}
	
	@Override
	public SimpleBbsDto viewDao(String id) {
		System.out.println("viewDao()");
		
		String query = "SELECT * FROM simple_bbs WHERE id = " + id;
		SimpleBbsDto dto = template.queryForObject(
				query, new BeanPropertyRowMapper<>(SimpleBbsDto.class));
		return dto;
	}
	
	@Override
	public Integer countDao() {
		System.out.println("countDao()");
		
		String query = "SELECT COUNT(*) FROM simple_bbs";
		Integer count = template.queryForObject(query, Integer.class);
		return count;
	}
	
	@Override
	public int writeDao(final String writer, final String title, final String content) {
		System.out.println("writeDao()");
		
		String query = "INSERT INTO simple_bbs(id, writer, title, content)"+
		"VALUES (simple_bbs_seq.nextval, ?, ?, ?)";
		return template.update(query, writer, title, content);
	}
	
	@Override
	public int deleteDao(final String id) {
		System.out.println("deleteDao()");
		
		String query = "DELETE FROM simple_bbs WHERE id = ?";
		return template.update(query, Integer.parseInt(id));
	}
}
