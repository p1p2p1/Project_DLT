package com.dlt.senior.board.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.dlt.senior.board.model.CommentVO;
import com.dlt.senior.board.service.IBoardService;



@Controller
public class BoardController {

	@Autowired
	IBoardService boardService;
	
	@GetMapping(value = "/")
	public String mainPage(Model model) {
		int page = 1;
		model.addAttribute("boardList", boardService.getBoardList(page));
		return "index";
	}
	
	@GetMapping(value = "/boardList/{page}")
	public String boardList(@PathVariable int page, Model model) {
		model.addAttribute("boardList", boardService.getBoardList(page));
		return "board/boardlist";
	}
	
	@GetMapping(value = "/boardView/{boardId}")
	public String boardView(@PathVariable int boardId, Model model) {
		model.addAttribute("board", boardService.getBoardView(boardId)); //글 조회
		model.addAttribute("commentList", boardService.getCommentList(boardId)); //댓글 조회
		
		return "board/boardView";
	}
	
	@PostMapping(value = "/boardView/commentWrite")
	public String commentWrite(@ModelAttribute CommentVO vo, Model model,HttpSession session) {		
		vo.setUserId((String) session.getAttribute("user_id"));
		vo.setcName((String) session.getAttribute("user_name"));
		
		boardService.insertComment(vo);
		
		return "board/boardView";
	}
	
}
