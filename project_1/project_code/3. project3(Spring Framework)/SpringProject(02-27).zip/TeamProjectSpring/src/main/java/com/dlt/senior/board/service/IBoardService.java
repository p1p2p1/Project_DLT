package com.dlt.senior.board.service;

import java.util.List;

import com.dlt.senior.board.model.BoardVO;
import com.dlt.senior.board.model.CommentVO;

public interface IBoardService {
	public List<BoardVO> getBoardList(int page); //게시판 글 목록 조회
	public BoardVO getBoardView(int boardId); //게시판 글 조회
	public List<CommentVO> getCommentList(int boardId); //게시판 댓글 조회
	public void insertComment(CommentVO vo); //댓글 작성
}
