package com.dlt.senior.policy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dlt.senior.policy.model.PolicyVO;
import com.dlt.senior.policy.service.IPolicyService;

@Controller
@RequestMapping("/policy")
public class PolicyController {
	
	@Autowired
	IPolicyService policyService;

	@GetMapping("")
	public String getPolicyPage() {
		return "policy/policy";
	}
	
	@GetMapping("job/{regionId}")
	public String getJobPage(@PathVariable int regionId, @ModelAttribute PolicyVO vo) {
		policyService.getJobPolicy(regionId,vo);
		return null;
	}
}
