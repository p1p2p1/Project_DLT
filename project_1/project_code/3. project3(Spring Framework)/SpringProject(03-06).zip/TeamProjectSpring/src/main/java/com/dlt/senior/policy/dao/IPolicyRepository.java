package com.dlt.senior.policy.dao;

public interface IPolicyRepository {

}
