package com.dlt.senior.policy.service;

import com.dlt.senior.policy.model.PolicyVO;

public interface IPolicyService {
	public PolicyVO getJobPolicy(int regionId, PolicyVO vo);
}
