package com.dlt.senior.policy.service;

import org.springframework.stereotype.Service;

import com.dlt.senior.policy.model.PolicyVO;

@Service
public class PolicyService implements IPolicyService{

	@Override
	public PolicyVO getJobPolicy(int regionId, PolicyVO vo) {
		vo.setRegionId(regionId);
		
		
		return null;
	}

}
