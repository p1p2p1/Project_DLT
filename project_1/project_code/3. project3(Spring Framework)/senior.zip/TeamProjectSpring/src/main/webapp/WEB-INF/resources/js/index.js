window.onload = function () {
    new WOW().init();
};

