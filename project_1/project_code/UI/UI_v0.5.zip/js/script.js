// 여기에 HTML 파일에서 이동한 모든 JavaScript 코드를 넣습니다.

window.onload = function () {
    var posts = [
        { id: 1, title: "강남구 범죄정보를 알려드립니다", author: "홍길동", date: "2023-11-30" },
        { id: 2, title: "강서구 범죄정보를 알려드립니다", author: "홍길순", date: "2023-11-30" },
        { id: 3, title: "서대문구 범죄정보를 알려드립니다", author: "홍길순", date: "2023-11-30" },
        { id: 4, title: "마포구 범죄정보를 알려드립니다", author: "홍길순", date: "2023-11-30" },
        { id: 5, title: "중구 범죄정보를 알려드립니다", author: "홍길순", date: "2023-11-30" },
        { id: 6, title: "종로구 범죄정보를 알려드립니다", author: "홍길순", date: "2023-12-04" },
        { id: 7, title: "용산구 범죄정보를 알려드립니다", author: "홍길순", date: "2023-12-04" },
    ];
    var tableBody = document.querySelector("#board-table tbody");
    for (var i = 0; i < posts.length; i++) {
        var row = document.createElement("tr");
        var idCell = document.createElement("th");
        idCell.textContent = posts[i].id;

        var titleCell = document.createElement("td");
        titleCell.innerHTML = '<a href ="#">' + posts[i].title + "</a>";

        var authorCell = document.createElement("td");
        authorCell.textContent = posts[i].author;

        var dateCell = document.createElement("td");
        dateCell.textContent = posts[i].date;

        row.appendChild(idCell);
        row.appendChild(titleCell);
        row.appendChild(authorCell);
        row.appendChild(dateCell);

        tableBody.appendChild(row);
    }
}









var type1 = 'bar';
var type2 = 'pie';
var type3 = 'line';
// 새로운 페이지에 chart를 그리는 함수. 

function drawChart(chartId, chartType, data) {
    var ctx = document.getElementById(chartId).getContext('2d');
    new Chart(ctx, {
        type: chartType,
        data: data,
        options: {}
    });
}
// 여기 데이타는 고정된 Data
var barChartData_fix = {
    labels: ['강남구', '강서구', '서대문구', '은평구', '도봉구', '영등포구', '용산구'],
    datasets: [{
        label: '2023년 자치구별 범죄정보(폭력)',
        data: [20, 30, -10, -20, 50, 55, -15],
        backgroundColor: ['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet'],
    }]
};
var pieChartData_fix = {
    labels: ['강남구', '강서구', '서대문구', '은평구', '도봉구', '영등포구', '용산구'],
    datasets: [{
        label: '2023년 자치구별 범죄정보(폭력)',
        data: [65, 59, 80, 81, 56, 55, 40],
        backgroundColor: ['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet'],
    }]
};

// 차트 그리기
drawChart('mainChart', 'line', barChartData_fix);



var mainChartData = {
    labels: ["레이블 1", "레이블 2", "레이블 3", "레이블 4", "레이블 5"],
    datasets: [
        {
            label: "데이터",
            data: [10, 20, 15, 30, 25], // 실제 데이터로 대체
            backgroundColor: "rgba(75, 192, 192, 0.2)",
            borderColor: "rgba(75, 192, 192, 1)",
            borderWidth: 1,
        },
    ],
};
var ctx2 = document.getElementById("mainChart").getContext("2d");

var myChart2 = new Chart2(ctx2, {
    type: "bar", // 차트 유형을 변경할 수 있습니다 (예: 'bar', 'line', 'pie' 등)
    data: mainChartData,
    options: {
        // 여기에서 차트 옵션을 사용자 정의합니다
        scales: {
            y: {
                beginAtZero: true,
            },
        },
    },
});