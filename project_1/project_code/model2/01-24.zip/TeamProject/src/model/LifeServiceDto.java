package model;

public class LifeServiceDto {
	private int expecId;
	private int year;
	private String region;
	private float expectancyLife;
	
	public int getExpecId() {
		return expecId;
	}
	public int getYear() {
		return year;
	}
	public String getRegion() {
		return region;
	}
	public float getExpectancyLife() {
		return expectancyLife;
	}
	public void setExpecId(int expecId) {
		this.expecId = expecId;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public void setExpectancyLife(float expectancyLife) {
		this.expectancyLife = expectancyLife;
	}
}
