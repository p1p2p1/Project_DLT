package command;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.BoardDao;
import model.BoardDto;

public class BListCommand implements BCommand{
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		BoardDao dao = BoardDao.getInstance();
		List<BoardDto> dtos = new ArrayList<BoardDto>();
		int page;
		int minPage;
		
		String pageInfo = (String) request.getAttribute("page");
		
		//메인 페이지
		if(pageInfo == "main") {
			page = 1;
			minPage = 1;
		}
		//게시판일 때
		else {
			page = Integer.parseInt(request.getParameter("page"));
			minPage = Integer.parseInt(request.getParameter("minPage")); 
		}
		
		//페이지네이션
		if(page <= 0) {
			page = 1;
		}
		
		if(minPage <= 0) {
			minPage = 1;
		}
		
		//URL 수정해서 접속하는 경우 방지
		if(minPage > page) {
			page = minPage;
		}
		
		int maxPage = minPage + 4;
		
		
		dtos = dao.boardList(page);
		
		request.setAttribute("boardList", dtos);
		request.setAttribute("page", page);
		request.setAttribute("minPage", minPage);
		request.setAttribute("maxPage", maxPage);
	}
}
