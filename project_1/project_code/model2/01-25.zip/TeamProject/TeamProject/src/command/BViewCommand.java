package command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.BoardDao;
import model.BoardDto;

public class BViewCommand implements BCommand{
	private BoardDao dao;
	
	public BViewCommand() {
		dao = BoardDao.getInstance();
	}

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		BoardDto dto = new BoardDto();
		int boardId = Integer.parseInt(request.getParameter("boardId"));
		
		dto.setBoardId(boardId);
		
		dao.boardView(dto);
		
		request.setAttribute("board", dto);
		request.setAttribute("list", dao.listComment(boardId));
	}

}
