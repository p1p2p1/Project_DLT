package command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;

public interface SDiseaseCommand {
	public JSONArray execute(HttpServletRequest request, HttpServletResponse response);
}
