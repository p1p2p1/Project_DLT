package command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;

import model.AreaServiceDao;

public class SDiseaseCommandImpl implements SDiseaseCommand {
	@Override
	public JSONArray execute(HttpServletRequest request, HttpServletResponse response) {
		String district =(String)request.getParameter("district");
	
		AreaServiceDao dao = AreaServiceDao.getInstance();
		JSONArray list = dao.getAllDiseaseData(district);
		return list;
	}
}
