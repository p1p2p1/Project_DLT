window.onload = function () {
    new WOW().init();
    getChartData();
};


//차트 저장 변수
var myChart;


//차트 틀
var chartData = {
    labels: [2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024],
    datasets: [
        {
            label: "서울특별시",
            backgroundColor: "#1c3664",
            borderColor: "#1c3664",
            borderWidth: 1,
        },
        {
            label: "전라남도",
            backgroundColor: "red",
            borderColor: "red",
            borderWidth: 1,
        }]
};



//fetch를 사용한 서비스 구현
function getChartData() {
    var regionFirst;
    var regionSecond;

    regionFirst = document.getElementById('selectedRegionFirst').value;
    regionSecond = document.getElementById('selectedRegionSecond').value;
    yearStart = document.getElementById('year-select-start').value;
    yearEnd = document.getElementById('year-select-end').value;

    //시작 연도가 더 큰 값을 설정할 때
    if (yearStart > yearEnd) {
        let temp;
        temp = yearStart;
        yearStart = yearEnd;
        yearEnd = temp;
    }

    //fetch(차트 비동기)
    fetch(`lifeService.do?regionFirst=${regionFirst}&regionSecond=${regionSecond}&yearStart=${yearStart}&yearEnd=${yearEnd}`)
        .then(response => response.json())
        .then(data => {
            let map = new Map();
            map.set(1, "서울특별시");
            map.set(2, "전라남도");
            map.set(3 ,"강원도");
            map.set(4, "경기도");
            map.set(5, "경상남도");
            map.set(6, "경상북도");
            map.set(7, "광주광역시");
            map.set(8, "대구광역시");
            map.set(9, "대전광역시");
            map.set(10, "부산광역시");
            map.set(11, "세종특별자치시");
            map.set(12, "울산광역시");
            map.set(13, "인천광역시");
            map.set(14, "전라북도");
            map.set(15, "제주특별자치도");
            map.set(16, "충청남도");
            map.set(17, "충청북도");
        	
        	var firstRegionData = data.filter(item => map.get(item.region_id) == regionFirst).map(item => item.value);
            var secondRegionData = data.filter(item => map.get(item.region_id) == regionSecond).map(item => item.value);

            var selectedYears = [];
            for (var i = parseInt(yearStart); i <= parseInt(yearEnd); i++) {
                selectedYears.push(String(i));
            }

            console.log(firstRegionData);
            console.log(secondRegionData);

            //라벨, 데이터 설정
            chartData.labels = selectedYears;
            chartData.datasets[0].label = regionFirst;
            chartData.datasets[1].label = regionSecond;
            chartData.datasets[0].data = firstRegionData;
            chartData.datasets[1].data = secondRegionData;
            drawChart("serviceChart", chartData);
        })
        .catch(error => {
            console.log("fetch가 제대로 작동하지 않습니다.");
        });


    if (myChart) {
        myChart.destroy();
    }
}


//chart load
function drawChart(chartId, data) {
    var ctx = document.getElementById(chartId).getContext('2d');
    myChart = new Chart(ctx, {
        type: "bar",
        data: data,
        options: {
            layout: {
                padding: 30
            },
            plugins: {
                title: {
                    display: true,
                    text: '각 지역 기대수명 데이터',

                    padding: {
                        top: 10,
                    }
                }
            }
            ,
            scales: {
                y: {
                    max: 88,
                    min: 80,
                    beginAtZero: false
                }
            }
            , responsive: true, //차트 반응형 옵션
            maintainAspectRatio: true,
        },
    });
    myChart.update();
}










