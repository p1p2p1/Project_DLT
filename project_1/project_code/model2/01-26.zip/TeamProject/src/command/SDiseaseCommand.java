package command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import model.AreaServiceDao;

public class SDiseaseCommand implements SCommand {
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		String district =(String)request.getParameter("district");
	
		AreaServiceDao dao = AreaServiceDao.getInstance();
		
		request.setAttribute("list", dao.getAllDiseaseData(district));
		
	}
}
