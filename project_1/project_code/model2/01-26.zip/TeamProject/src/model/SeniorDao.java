package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class SeniorDao {
	
	private static SeniorDao instance = new SeniorDao();
	
	public static SeniorDao getInstance() {
		return instance;
	}
	
	public ArrayList<SeniorDto> getWelfare(String gubun){
		ArrayList<SeniorDto> welfareDtos = new ArrayList<SeniorDto>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = "SELECT GUBUN, SEQ, ORGNAME, ADDRSEQ, ADDRESS, TELNO, JACHIGU, ETCINFO FROM WELFARE WHERE GUBUN = ? ORDER BY DATASEQ, ADDRSEQ";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, gubun);
			rs = pstmt.executeQuery();
			
			System.out.println("복지관현황");
			while (rs.next()) {
				SeniorDto dto = new SeniorDto();
				dto.setSeq(rs.getInt("SEQ"));
				dto.setOrgName(rs.getString("ORGNAME"));
				dto.setAddrSeq(rs.getString("ADDRSEQ"));
				dto.setAddress(rs.getString("ADDRESS"));
				dto.setTelno(rs.getString("TELNO"));
				dto.setJachigu(rs.getString("JACHIGU"));
				dto.setEtcInfo(rs.getString("ETCINFO"));
				welfareDtos.add(dto);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn != null) {
					conn.close();
				}if(rs != null) {
					rs.close();
				}if(pstmt != null) {
					pstmt.close();
				}
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return welfareDtos;
	}
	
	public ArrayList<SeniorDto> getSeoulSocial(){
		ArrayList<SeniorDto> welfareDtos = new ArrayList<SeniorDto>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = "SELECT SEQ, CATEGORY, DTLCATEGORY, BIZCON, SUPPORTCON FROM JOB_SOCIAL";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			
			System.out.println("서울 사회서비스");
			while (rs.next()) {
				SeniorDto dto = new SeniorDto();
				dto.setSeq(rs.getInt("SEQ"));
				dto.setCategory(rs.getString("CATEGORY"));
				dto.setDtlCategory(rs.getString("DTLCATEGORY"));
				dto.setBizCon(rs.getString("BIZCON"));
				if(rs.getString("SUPPORTCON") != null) {
					dto.setSupportCon(rs.getString("SUPPORTCON").replaceAll("\n", "<br>"));
				}
				
				welfareDtos.add(dto);
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(conn != null) {
					conn.close();
				}if(rs != null) {
					rs.close();
				}if(pstmt != null) {
					pstmt.close();
				}
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		
		}
		return welfareDtos;
	}
	
	public ArrayList<SeniorDto> getSeoulMarket(){
		ArrayList<SeniorDto> welfareDtos = new ArrayList<SeniorDto>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = "SELECT SEQ, DTLCATEGORY, JOBCON, SUPPORTCON FROM SEOULJOB_MARKET";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			
			System.out.println("서울 시장형사업단");
			while (rs.next()) {
				SeniorDto dto = new SeniorDto();
				dto.setSeq(rs.getInt("SEQ"));
				dto.setDtlCategory(rs.getString("DTLCATEGORY"));
				dto.setJobCon(rs.getString("JOBCON"));
				if(rs.getString("SUPPORTCON") != null) {
					dto.setSupportCon(rs.getString("SUPPORTCON").replaceAll("\n", "<br>"));
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(conn != null) {
					conn.close();
				}if(rs != null) {
					rs.close();
				}if(pstmt != null) {
					pstmt.close();
				}
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		
		}
		
		return welfareDtos;
	}
	
	public ArrayList<SeniorDto> getSeoulPublic(){
		ArrayList<SeniorDto> welfareDtos = new ArrayList<SeniorDto>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = "SELECT CATEGORY, DTLBIZCON, JOBSAM, SUPPORTCON FROM SEOULJOB_PUBLIC";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			
			System.out.println("서울 공익활동");
			while (rs.next()) {
				SeniorDto dto = new SeniorDto();
				dto.setCategory(rs.getString("CATEGORY"));
				dto.setDtlBizCon(rs.getString("DTLBIZCON"));
				dto.setJobSam(rs.getString("JOBSAM"));
				if(rs.getString("SUPPORTCON") != null) {
					dto.setSupportCon(rs.getString("SUPPORTCON").replaceAll("\n", "<br>"));
				}
				
				welfareDtos.add(dto);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(conn != null) {
					conn.close();
				}if(rs != null) {
					rs.close();
				}if(pstmt != null) {
					pstmt.close();
				}
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		
		}
		
		return welfareDtos;
	}
	
	private Connection getConnection() {
		Context context = null;
		DataSource dataSource = null;
		Connection conn = null;
		
		try {
			context = new InitialContext();
			dataSource = (DataSource)context.lookup("java:comp/env/jdbc/Oracle11g");
			conn = dataSource.getConnection();
		}
		catch (Exception e){
			e.printStackTrace();
		}
		
		return conn;
		
	} 

}
