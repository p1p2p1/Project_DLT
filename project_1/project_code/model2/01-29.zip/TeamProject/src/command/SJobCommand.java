package command;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.SeniorDao;
import model.SeniorDto;

public class SJobCommand implements SCommand{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		SeniorDao dao = SeniorDao.getInstance();
		
		String regionId = request.getParameter("region_id");
		
		SeniorDto dto = new SeniorDto();
		dto.setRegionId(regionId);
		
		
		ArrayList<SeniorDto> publicDtos = dao.getPublic(dto);
		ArrayList<SeniorDto> socialDtos = dao.getSocial(dto);
		ArrayList<SeniorDto> marketDtos = dao.getMarket(dto);
		
		
		request.setAttribute("publicDtos", publicDtos);
		request.setAttribute("socialDtos", socialDtos);
		request.setAttribute("marketDtos", marketDtos);
		
		
		
	}
	
}
