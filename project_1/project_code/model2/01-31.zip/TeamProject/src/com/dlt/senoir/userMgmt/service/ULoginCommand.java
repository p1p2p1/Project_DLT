package com.dlt.senoir.userMgmt.service;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dlt.senior.policy.dao.MemberDao;
import com.dlt.senior.policy.model.MemberDto;

public class ULoginCommand implements UCommand{
	private MemberDao dao;
	
	public ULoginCommand() {
		dao = MemberDao.getInstance();
	}
	
	public void execute(HttpServletRequest request, HttpServletResponse response){
    	MemberDto dto = new MemberDto();
		
		dto.setId(request.getParameter("user_id"));
    	dto.setPw(request.getParameter("user_pw"));
    	
    	dao.checkId(dto);
    	
    	request.setAttribute("user_name", dto.getName());
    	request.setAttribute("user_id", dto.getId());

    	
	}
}
