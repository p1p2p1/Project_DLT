package model;

public class DistrictDto {

	private String District_Id;
	private String District_Name;
	private String Region_Id;

	public String getDistrict_Id() {
		return District_Id;
	}

	public void setDistrict_Id(String district_Id) {
		District_Id = district_Id;
	}

	public String getDistrict_Name() {
		return District_Name;
	}

	public void setDistrict_Name(String district_Name) {
		District_Name = district_Name;
	}

	public String getRegion_Id() {
		return Region_Id;
	}

	public void setRegion_Id(String region_Id) {
		Region_Id = region_Id;
	}
}
