let content;
let editContent;

window.onload = function(){
	content = document.getElementById("summernote").value;
}





document.getElementById('editForm').addEventListener('submit', function(event) {
	editContent = document.getElementById("summernote").value;
	
	if(content == editContent){
		event.preventDefault(); // 폼 제출 취소
		alert("글 내용을 수정해주세요.");
	}
});