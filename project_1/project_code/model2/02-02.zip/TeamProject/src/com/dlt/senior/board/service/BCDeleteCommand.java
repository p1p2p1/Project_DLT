package com.dlt.senior.board.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dlt.senior.board.dao.BoardDao;
import com.dlt.senior.board.model.CommentDto;

public class BCDeleteCommand implements BCommand{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		BoardDao dao = BoardDao.getInstance();
		CommentDto dto = new CommentDto();
		int cId = Integer.parseInt(request.getParameter("cId"));
		int cStep = Integer.parseInt(request.getParameter("cStep"));
		
		
		
		dto.setcId(cId);
		dto.setcStep(cStep);
		
		dao.deleteCommand(dto);
	}

}
