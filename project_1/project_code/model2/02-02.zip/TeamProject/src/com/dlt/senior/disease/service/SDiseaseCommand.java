package com.dlt.senior.disease.service;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

import com.dlt.senior.disease.dao.AreaServiceDao;

public class SDiseaseCommand implements SDCommand {
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		String district =(String)request.getParameter("district");
	
		AreaServiceDao dao = AreaServiceDao.getInstance();
		
		request.setAttribute("list", dao.getAllDiseaseData(district));
		
	}
}
