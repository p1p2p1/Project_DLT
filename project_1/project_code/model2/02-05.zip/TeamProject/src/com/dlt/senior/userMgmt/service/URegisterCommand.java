package com.dlt.senior.userMgmt.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dlt.senior.useMgmt.model.MemberDto;
import com.dlt.senior.userMgmt.dao.MemberDao;

public class URegisterCommand implements UCommand{
	private MemberDao dao;
	
	public URegisterCommand() {
		dao = MemberDao.getInstance();
	}

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
    	MemberDto dto = new MemberDto();
		
		dto.setId(request.getParameter("id"));
    	dto.setPw(request.getParameter("pw"));
    	dto.setPhone(request.getParameter("phone"));
    	dto.setName(request.getParameter("name"));
    	dto.setEmail(request.getParameter("email"));
		
		dao.registerMember(dto);
	}

}
