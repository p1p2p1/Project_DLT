package com.dlt.senior.disease.model;

public class AreaDto {
	private String Region_Name;
	private String Region_Id;

	public String getRegion_Name() {
		return Region_Name;
	}
	public void setRegion_Name(String region_Name) {
		Region_Name = region_Name;
	}
	public String getRegion_Id() {
		return Region_Id;
	}
	public void setRegion_Id(String region_Id) {
		Region_Id = region_Id;
	}
	
}
