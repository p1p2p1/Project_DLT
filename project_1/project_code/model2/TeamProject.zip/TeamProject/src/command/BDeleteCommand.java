package command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.BoardDao;
import model.BoardDto;

public class BDeleteCommand implements BCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		int boardId = Integer.parseInt(request.getParameter("boardId"));
		BoardDao dao = BoardDao.getInstance();
		
		BoardDto dto = new BoardDto();
		dto.setBoardId(boardId);
		
		dao.boardDelete(dto);
	}

}
