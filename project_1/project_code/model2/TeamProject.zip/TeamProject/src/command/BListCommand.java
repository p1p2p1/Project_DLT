package command;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.BoardDao;
import model.BoardDto;

public class BListCommand implements BCommand{
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		BoardDao dao = BoardDao.getInstance();
		List<BoardDto> dtos = new ArrayList<BoardDto>();
		
		//페이지네이션
		int page = Integer.parseInt(request.getParameter("page"));
		int minPage = Integer.parseInt(request.getParameter("minPage")); 
		
		if(page <= 0) {
			page = 1;
		}
		
		if(minPage <= 0) {
			minPage = 1;
		}
		int maxPage = minPage + 4;
		
		
		
		dtos = dao.boardList(page);

//		//글이 없는 경우
//		if(dtos.get(0).getBoardTitle() == null) {
//			//게시판 구성
//		}
		
		request.setAttribute("boardList", dtos);
		request.setAttribute("page", page);
		request.setAttribute("minPage", minPage);
		request.setAttribute("maxPage", maxPage);
	}
}
