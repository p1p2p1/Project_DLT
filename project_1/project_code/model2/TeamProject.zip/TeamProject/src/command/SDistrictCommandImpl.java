package command;

import java.util.ArrayList;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.DistrictDto;
import model.AreaServiceDao;

public class SDistrictCommandImpl implements SDistrictCommand {
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("area");
		AreaServiceDao dao = AreaServiceDao.getInstance();
		ArrayList<DistrictDto> list =  dao.listDistrict(id); 
		request.setAttribute("list", list);
		request.setAttribute("area", dao.getArea(id));
	}
}
