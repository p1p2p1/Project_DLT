package command;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.LifeServiceDto;

public interface SLifeCommand {
	public List<LifeServiceDto> execute(HttpServletRequest request,HttpServletResponse response);
}
