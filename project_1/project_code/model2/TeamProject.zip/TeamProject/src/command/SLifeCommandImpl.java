package command;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.LifeServiceDao;
import model.LifeServiceDto;

public class SLifeCommandImpl implements SLifeCommand{

	@Override
	public List<LifeServiceDto> execute(HttpServletRequest request, HttpServletResponse response) {
		LifeServiceDao lifeDao = LifeServiceDao.getInstance();
		
		String regionFirst = request.getParameter("regionFirst");
		String regionSecond = request.getParameter("regionSecond");
		String yearStart = request.getParameter("yearStart");
		String yearEnd = request.getParameter("yearEnd");
		
		List<LifeServiceDto> list = lifeDao.lifeList(regionFirst, regionSecond, yearStart, yearEnd);
		
		return list;
	}

}
