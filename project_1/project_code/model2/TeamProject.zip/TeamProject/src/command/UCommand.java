package command;

import model.MemberDto;

public interface UCommand {
	public MemberDto execute(MemberDto dto);
}
