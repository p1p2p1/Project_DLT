package command;

import model.MemberDao;
import model.MemberDto;

public class ULoginCommand implements UCommand{
	private MemberDao dao;
	
	public ULoginCommand() {
		dao = MemberDao.getInstance();
	}
	
	public MemberDto execute(MemberDto dto){
		dao.checkId(dto);
		return dto;
	}
}
