package command;

import model.MemberDao;
import model.MemberDto;

public class URegisterCommand implements UCommand{
	private MemberDao dao;
	
	public URegisterCommand() {
		dao = MemberDao.getInstance();
	}

	@Override
	public MemberDto execute(MemberDto dto) {
		dao.registerMember(dto);
		return dto;
	}

}
