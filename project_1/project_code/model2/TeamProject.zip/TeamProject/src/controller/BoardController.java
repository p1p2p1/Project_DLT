package controller;

import java.io.IOException;




import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import command.BCommand;
import command.BDeleteCommand;
import command.BEditCommand;
import command.BEditViewCommand;
import command.BListCommand;
import command.BViewCommand;
import command.BWriteCommand;

@WebServlet({"/boardList.do","/boardWrite.do", "/boardView.do", "/boardEditView.do", "/boardEdit.do", "/boardDelete.do"})
public class BoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doHandle(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doHandle(request,response);
	}
	
	private void doHandle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset = utf-8");
		
		String path = request.getContextPath(); 
		String uri = request.getRequestURI();	
		String command = uri.substring(path.length());
		System.out.println("사용한 커맨드  : " + command);
		
		//view board list
		if(command.equals("/boardList.do")) {
			BCommand board  = new BListCommand();
			board.execute(request, response);
			RequestDispatcher dispatch = request.getRequestDispatcher("boardList.jsp");
			dispatch.forward(request, response);
		}
		//write board
		else if(command.equals("/boardWrite.do")) {
			String cspPolicy = "script-src 'self'; style-src 'self';";// CSP setting
			response.setHeader("Content-Security-Policy", cspPolicy); //XSS prevetion
			BCommand board  = new BWriteCommand();

			board.execute(request, response);
			
			response.sendRedirect("boardList.do");
		}
		//board view
		else if(command.equals("/boardView.do")) {
			BCommand board = new BViewCommand();
		
			board.execute(request, response);
			RequestDispatcher dispatch = request.getRequestDispatcher("boardView.jsp");
			dispatch.forward(request, response);
		}
		
		//board edit View
		else if(command.equals("/boardEditView.do")) {
			BCommand board = new BEditViewCommand();
			
			board.execute(request, response);
			
			
			if(request.getAttribute("boardTitle").equals("differ")) {
				response.sendRedirect("boardEditError.jsp");
			}
			else {
				RequestDispatcher dispatch = request.getRequestDispatcher("boardEdit.jsp");
				dispatch.forward(request, response);
			}
		}
		
		//board edit
		else if(command.equals("/boardEdit.do")) {
			String cspPolicy = "script-src 'self'; style-src 'self';";// CSP setting
			response.setHeader("Content-Security-Policy", cspPolicy); //XSS prevetion
			BCommand board = new BEditCommand();
			board.execute(request, response);
			response.sendRedirect("boardList.do?page=1&minPage=1");
		}
		
		//board delete
		else if(command.equals("/boardDelete.do")) {
			BCommand board = new BDeleteCommand();
			board.execute(request, response);
			response.sendRedirect("boardList.do?page=1&minPage=1");
		}
	}

}
