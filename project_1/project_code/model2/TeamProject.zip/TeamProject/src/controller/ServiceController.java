package controller;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import command.SDiseaseCommand;
import command.SDiseaseCommandImpl;
import command.SDistrictCommand;
import command.SDistrictCommandImpl;
import command.SLifeCommand;
import command.SLifeCommandImpl;
import model.LifeServiceDto;


@WebServlet({"/lifeService.do","/Chart.do", "/getChart.do"})
public class ServiceController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doHandle(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doHandle(request, response);
	}
	private void doHandle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset = utf-8");
		
		String path = request.getContextPath();
		String uri = request.getRequestURI();
		String command = uri.substring(path.length());
		System.out.println(command);
		
		//기대 수명 정보 서비스
		//기대 수명 정보 불러오기
		if("/lifeService.do".equals(command)) {
			SLifeCommand sLife = new SLifeCommandImpl();
			List<LifeServiceDto> list = sLife.execute(request, response);
			
			JSONArray jsonArray = new JSONArray();
			
			for(LifeServiceDto data : list) {
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("year", data.getYear());
				jsonObject.put("region", data.getRegion());
				jsonObject.put("value", data.getExpectancyLife());
				jsonArray.put(jsonObject);
			}
		
			String json = jsonArray.toString();
			
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			
			response.getWriter().write(json);
		}
		//지역 통계 서비스
		//차트 지역 정보
		else if ("/Chart.do".equals(command)) {
			SDistrictCommand acc = new SDistrictCommandImpl();
			acc.execute(request, response);
			RequestDispatcher dispatcher = request.getRequestDispatcher("statisticsService.jsp");
			dispatcher.forward(request, response);
		} 
		//차트 데이터
		else if ("/getChart.do".equals(command)) {
			response.setHeader("Access-Control-Allow-Origin", "*");
			SDiseaseCommand gcc = new SDiseaseCommandImpl();
			JSONArray jsonData = gcc.execute(request, response);
			PrintWriter out = response.getWriter();
			out.print(jsonData.toString());
			out.flush();
		}
	}

}
