package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import command.UCommand;
import command.ULoginCommand;
import command.URegisterCommand;
import model.MemberDto;

@WebServlet({"/login.do", "/logout.do", "/beforeLogin.do", "/registerMember.do" })
public class UserMgmtController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doHandle(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doHandle(request,response);
	}
	

	private void doHandle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset = utf-8");
		
		HttpSession sess = request.getSession();
		
		String path = request.getContextPath(); 
		String uri = request.getRequestURI();	
		String command = uri.substring(path.length());
		System.out.println("사용한 커맨드  : " + command);
		

		//login
	    if ("/login.do".equals(command)) {
	    	MemberDto dto = new MemberDto();
	    	UCommand login = new ULoginCommand();
	    	
	    	dto.setId(request.getParameter("user_id"));
	    	dto.setPw(request.getParameter("user_pw"));
	    	String returnURL = (String) sess.getAttribute("returnURL");
	    	login.execute(dto);
	    	
	    	//Login logic
	    	if(dto.getName() == null) { //login fail
	    		if(sess.getAttribute("login_try") == null) { //new session
	    			int loginTry = 1;
	    			sess.setAttribute("login_try", loginTry);
	    		}
	    		else {//session try
	    			int loginTry = (int) sess.getAttribute("login_try");
	    			++loginTry;
	    			sess.setAttribute("login_try",loginTry);
	    		}
	    		RequestDispatcher dispatch = request.getRequestDispatcher("loginFail.jsp");
	    		dispatch.forward(request,response);
	    	}else {//login success
	    		sess.setAttribute("user_id", dto.getId()); //session input loginid
	    		sess.setAttribute("user_name", dto.getName()); //session input loginname For board input
	    	
	    		if(returnURL == null) {
	    			response.sendRedirect("index.jsp"); //Login after server initialization
	    		}
	    		else if(returnURL.equals("http://localhost:8181/TeamProject/registration.jsp")){
	    			response.sendRedirect("index.jsp");
	    		}
	    		else {
		    		response.sendRedirect(returnURL); //request the previous page
	    		}	
	    	}
	    	
	    	
	    }
		//logout
	    else if ("/logout.do".equals(command)) {
			String returnURL = request.getHeader("Referer");
			sess.setAttribute("returnURL", returnURL);
	    	sess.invalidate();
	    	response.sendRedirect(returnURL);
	    	}
	    //before page save
	    else if("/beforeLogin.do".equals(command)) {
			String returnURL = request.getHeader("Referer");
			sess.setAttribute("returnURL", returnURL);
			response.sendRedirect("login.jsp");
			}
	  //register member
	    else if("/registerMember.do".equals(command)) {
	    	MemberDto dto = new MemberDto();
	    	UCommand register = new URegisterCommand();
	    	String returnURL = request.getHeader("Referer");
	    	sess.setAttribute("returnURL", returnURL);
	    	
	    	dto.setId(request.getParameter("id"));
	    	dto.setPw(request.getParameter("pw"));
	    	dto.setPhone(request.getParameter("phone"));
	    	dto.setName(request.getParameter("name"));
	    	dto.setEmail(request.getParameter("email"));
	    	register.execute(dto);
	    	response.sendRedirect("registrationCheck.jsp");
	    }
	}
}
