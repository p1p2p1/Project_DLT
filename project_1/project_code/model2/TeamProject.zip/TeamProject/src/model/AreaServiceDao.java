package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.json.JSONArray;
import org.json.JSONObject;


public class AreaServiceDao {

	private static AreaServiceDao instance;

	private Connection getConnection() {
		Context context = null;
		DataSource dataSource = null;
		Connection connection = null;
		try {
			context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g");
			connection = dataSource.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
	}

	public static AreaServiceDao getInstance() {
		if (instance == null) {
			instance = new AreaServiceDao();
		}
		return instance;	
	}
	
	public String getArea(String id) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String Region_Name = null;
		try {
			con = getConnection();
			String query = "SELECT * FROM region WHERE region_id = ?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				Region_Name = rs.getString("region_name");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
				pstmt.close();
				rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return Region_Name;
	}

	public ArrayList<DistrictDto> listDistrict(String id) {
		ArrayList<DistrictDto> list = new ArrayList<DistrictDto>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		DistrictDto dto = null;
		try {
			con = getConnection();
			String query = "SELECT region.*, district.* FROM region INNER JOIN district ON region.region_id = district.region_id WHERE region.region_id = ?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				String District_Id = rs.getString("district_id");
				String District_Name = rs.getString("district_name");
				dto = new DistrictDto();
				dto.setDistrict_Id(District_Id);
				dto.setDistrict_Name(District_Name);
				list.add(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
				pstmt.close();
				rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return list;
	}
	
	public JSONArray getAllDiseaseData(String district) {
		JSONArray jsonArray = new JSONArray();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			con = getConnection();
			String query = "SELECT * FROM disease where district_id = ?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, district);
			rs = pstmt.executeQuery();
			while (rs.next()) {
			    JSONObject jsonObject = new JSONObject();
			    jsonObject.put("data_id", rs.getInt("data_id"));
			    jsonObject.put("district_id", rs.getInt("district_id"));
			    jsonObject.put("dementia_data", rs.getDouble("dementia_data"));
			    jsonObject.put("diabetes_data", rs.getDouble("diabetes_data"));
			    jsonObject.put("hyperlipidemia_data", rs.getDouble("hyperlipidemia_data"));
			    jsonObject.put("hypertension_data", rs.getDouble("hypertension_data"));
			    jsonObject.put("year", rs.getInt("year"));
			    jsonArray.put(jsonObject);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonArray;
	}
}
