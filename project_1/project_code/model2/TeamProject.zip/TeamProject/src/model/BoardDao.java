package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class BoardDao {
	private DataSource dataFactory;
	public static BoardDao instance;
	
	public BoardDao() {
		try {
			Context ctx = new InitialContext();
			dataFactory = (DataSource) ctx.lookup("java:comp/env/jdbc/Oracle11g");
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//singleton
	public static BoardDao getInstance() {
		if(instance == null) {
			instance = new BoardDao();
		}
		return instance;
	}
	
	//board list
	public List<BoardDto> boardList(int page) {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			List<BoardDto> list = new ArrayList<BoardDto>();
			BoardDto dto;
			
			con = dataFactory.getConnection();
			//(n-1) * 5 < x <= n * 5
			String query = "SELECT * FROM (SELECT temp.*, ROWNUM rnum FROM (SELECT * FROM board ORDER BY b_date DESC) temp WHERE ROWNUM <= ? * 5)WHERE rnum > 5 * (?-1)";
			stmt = con.prepareStatement(query);
		
			stmt.setInt(1, page);
			stmt.setInt(2, page);
			rs = stmt.executeQuery();
			
			while(rs.next()) {
				dto = new BoardDto();
				dto.setBoardId(rs.getInt("b_id"));
				dto.setUserName(rs.getString("b_name"));
				dto.setUserId(rs.getString("ab_id"));
				dto.setBoardDate(rs.getDate("b_date"));
				dto.setBoardTitle(rs.getString("b_title"));
				dto.setBoardViews(rs.getInt("b_views"));
				
				//조회 추가
				list.add(dto);
			}
			
			return list;
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(stmt != null) {
					stmt.close();
				}if(con != null) {
					con.close();
				}if(rs != null) {
					rs.close();
				}
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		return null;
		

	}
	
	//board write
	public void boardWrite(BoardDto dto) {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = dataFactory.getConnection();
		
			String query = "INSERT INTO board (b_id, ab_id, b_name, b_title, b_content, b_date) VALUES (board_id.NEXTVAL, ?, ?, ?, ?, SYSDATE)";
			String userId = dto.getUserId();
			String userName = dto.getUserName();
			String title = dto.getBoardTitle();
			String content = dto.getBoardContent();
			
			stmt = con.prepareStatement(query);
			
			stmt.setString(1, userId);
			stmt.setString(2, userName);
			stmt.setString(3, title);
			stmt.setString(4, content);
			stmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(stmt != null) {
					stmt.close();
				}if(con != null) {
					con.close();
				}
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	//board detail
	public void boardView(BoardDto dto) {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = dataFactory.getConnection();
			String query = "SELECT * FROM board WHERE b_id = ?";
			int boardId = dto.getBoardId();
			int views = 0;
			stmt = con.prepareStatement(query);
			stmt.setInt(1, boardId);
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				String title = rs.getString("b_title");
				String name = rs.getString("b_name");
				String content = rs.getString("b_content");
				views = rs.getInt("b_views");
				Date date = rs.getDate("b_date");
				views++;
				
				dto.setBoardTitle(title);
				dto.setUserName(name);
				dto.setBoardContent(content);
				dto.setBoardDate(date);
				dto.setBoardViews(views);
			}
			rs.close();
			stmt.close();
			
			//조회수 추가
			String queryViews = "UPDATE board SET b_views = ? WHERE b_id = ?";
			stmt = con.prepareStatement(queryViews);
			stmt.setInt(1, views);
			stmt.setInt(2, boardId);
			stmt.executeUpdate();
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(con != null) {
					con.close();
				}if(stmt != null) {
					stmt.close();
				}
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	//board Edit View
	public void boardEditView(BoardDto dto) {
		Connection con = null;
		PreparedStatement stmt = null;
		
		try {
			con = dataFactory.getConnection();
			String query = "SELECT * FROM board WHERE b_id = ?";
			int b_id = dto.getBoardId();
			stmt = con.prepareStatement(query);
			stmt.setInt(1, b_id);
			ResultSet rs =stmt.executeQuery();
			
			rs.next();
			String userId = dto.getUserId();
			String boardUserId = rs.getString("ab_id");
			
			//글에 저장된 userid와 세션에 로그인된 userid를 비교
			if(boardUserId.equals(userId)) { //같을 때
				String boardTitle = rs.getString("b_title");
				String boardContent = rs.getString("b_content");
				String userName = rs.getString("b_name");
				//헷갈리지말것(보드의 아이디가 저장된 공간)
				int boardId = rs.getInt("b_id");
				Date boardDate = rs.getDate("b_Date");
				
				dto.setBoardId(boardId);
				dto.setBoardTitle(boardTitle);
				dto.setBoardContent(boardContent);
				dto.setUserName(userName);
				dto.setBoardDate(boardDate);
			}
			//다른 경우
			else {
				String boardTitle = "differ";
				dto.setBoardTitle(boardTitle);
			}
			
			rs.close();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(con != null) {
					con.close();
				}if(stmt != null) {
					stmt.close();
				}
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	//board Edit
	public void boardEdit(BoardDto dto) {
		Connection con = null;
		PreparedStatement stmt = null;
		
		try {
			con = dataFactory.getConnection();
			String query = "UPDATE board SET b_title = ?, b_content = ?,b_date = SYSDATE WHERE b_id = ?";
			stmt = con.prepareStatement(query);
			
			stmt.setString(1, dto.getBoardTitle());
			stmt.setString(2, dto.getBoardContent());
			stmt.setInt(3, dto.getBoardId());
			
			stmt.executeUpdate();
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(con != null) {
					con.close();
				}if(stmt != null) {
					stmt.close();
				}
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	//board Delete
	public void boardDelete(BoardDto dto) {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = dataFactory.getConnection();
			String query = "DELETE FROM board WHERE b_id = ?";
			stmt = con.prepareStatement(query);
			int boardId = dto.getBoardId();
			
			stmt.setInt(1, boardId);
			stmt.executeQuery();
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(con != null) {
					con.close();
				}if(stmt != null) {
					stmt.close();
				}
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
}
