package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class LifeServiceDao {
	private DataSource dataFactory;
	public static LifeServiceDao instance;
	
	public LifeServiceDao() {
		try {
			Context ctx = new InitialContext();
			dataFactory = (DataSource) ctx.lookup("java:comp/env/jdbc/Oracle11g");
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static LifeServiceDao getInstance() {
		if(instance == null) {
			instance = new LifeServiceDao();
		}
		return instance;
	}
	
	public List<LifeServiceDto> lifeList(String regionFirst, String regionSecond, String yearStart, String yearEnd){
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = dataFactory.getConnection();
			String query = "SELECT * FROM life_expectancy WHERE lifeyear >= ? AND lifeyear <= ? AND (region = ? OR region = ?)";
			stmt = con.prepareStatement(query);
			int start = Integer.parseInt(yearStart);
			int end = Integer.parseInt(yearEnd);
			stmt.setInt(1, start);
			stmt.setInt(2, end);
			stmt.setString(3, regionFirst);
			stmt.setString(4, regionSecond);
			ResultSet rs = stmt.executeQuery();
			
			List<LifeServiceDto> list = new ArrayList<LifeServiceDto>();
			
			LifeServiceDto lifeDto;

			while(rs.next()) {
				lifeDto = new LifeServiceDto();
				String lifeyear = rs.getString("lifeyear");
				String region = rs.getString("region");
				float lifeExpectancy = rs.getFloat("expectancylife");
				lifeDto.setYear(Integer.parseInt(lifeyear));
				lifeDto.setRegion(region);
				lifeDto.setExpectancyLife(lifeExpectancy);
				list.add(lifeDto);
				//현재 여기에서 두번 도는 문제 -> 지역이 2개니까 연도도 2배임
			}
			return list;
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(stmt != null) {
					stmt.close();
				}if(con != null) {
					con.close();
				}
			
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
	
		
		return null;
	}
}
