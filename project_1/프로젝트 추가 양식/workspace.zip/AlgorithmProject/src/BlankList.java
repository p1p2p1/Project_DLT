
public class BlankList {
	public static void main(String[] args) {
		String[] park = {"123", "OOO", "OOO"};

		System.out.println(Character.getNumericValue(park[0].charAt(1)));
	}
}
