
public class LinearListFirst {
	public static void main(String[] args) {
			int[][] sale = new int[2][4];
			sale[0][0] = 63;
			sale[0][1] = 84;
			sale[0][2] = 140;
			sale[0][3] = 130;
			
			sale[1][0] = 157;
			sale[1][1] = 209;
			sale[1][2] = 251;
			sale[1][3] = 312;
			
			for(int i = 0;i < 2;i++) {
				for(int j = 0;j < 4;j++) {
					System.out.printf("%d/4분기 : sale[%d][%d] = %d \n", j + 1, i, j, sale[i][j]);
				}
				System.out.println();
			}
	}
}
