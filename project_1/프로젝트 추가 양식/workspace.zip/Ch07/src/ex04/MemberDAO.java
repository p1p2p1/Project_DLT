package ex04;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class MemberDAO {
//	private static final String url = "jdbc:oracle:thin:@localhost:1521:XE";
//	private static final String user = "scott";
//	private static final String pwd = "tiger";
	private Connection con;
	private PreparedStatement stmt;
	private DataSource dataFactory;
	
	
	public MemberDAO() {
		try {
			//InitialContext는 Context 인터페이스를 상속받은 클래스다.
			Context ctx = new InitialContext();
			//JNDI 조회 "java:/comp/env"는 JNDI 리소스의 Java EE 표준 경로
			Context envContext = (Context) ctx.lookup("java:/comp/env");
			// jdbc/Oracle11g는 context.xml의 Resource 태그를 찾아보면 볼 수 있다.
			dataFactory = (DataSource) envContext.lookup("jdbc/Oracle11g");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public List<MemberVO> listMembers(){
		List<MemberVO> list = new ArrayList<>();
		try {
			con = dataFactory.getConnection();
			String query = "SELECT * FROM t_member";
//			connDB(query);
			stmt = con.prepareStatement(query);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				String id = rs.getString("id");
				String pwd = rs.getString("pwd");
				String name = rs.getString("name");
				String email = rs.getString("email");
				Date joinDate = rs.getDate("joinDate");
				MemberVO vo = new MemberVO();
				
				vo.setId(id);
				vo.setPwd(pwd);
				vo.setName(name);
				vo.setEmail(email);
				vo.setJoinDate(joinDate);
				list.add(vo);
			}
			rs.close();
			stmt.close();
			con.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public int addMember(MemberVO memberVO) throws SQLIntegrityConstraintViolationException {
		try {
			con = dataFactory.getConnection();
			String id = memberVO.getId();
			String pwd = memberVO.getPwd();
			String name = memberVO.getName();
			String email = memberVO.getEmail();
			String query = "INSERT INTO t_member";
			query += "(id, pwd, name, email)";
			query += "VALUES(?,?,?,?)";
			stmt = con.prepareStatement(query);
			stmt.setString(1, id);
			stmt.setString(2, pwd);
			stmt.setString(3, name);
			stmt.setString(4, email);
			int time = stmt.executeUpdate();
			System.out.println(time);
			stmt.close();
		}catch(SQLIntegrityConstraintViolationException e) {
			return 0; //SQL 무결성 위배
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return 1;
	}
	
	public void delMember(String id) {
		try {
			con = dataFactory.getConnection();
			String query = "DELETE FROM t_member " + "WHERE id = ?";
			stmt = con.prepareStatement(query);
			stmt.setString(1, id);
			int time = stmt.executeUpdate();
			System.out.println(time);
			stmt.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
//	private void connDB(String query) {
//		try {
//			System.out.println("Oracle 드라이버 로딩");
//			con = DriverManager.getConnection(url, user, pwd);
//			System.out.println("Connection 생성 성공");
//			stmt = con.prepareStatement(query);
//			System.out.println("Statement 생성 성공");
//		}catch(Exception e) {
//			e.printStackTrace();
//		}
//	}
}
