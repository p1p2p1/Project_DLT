package ex04;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Date;
import java.util.List;

import javax.naming.Context;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/member")
public class MemberServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			doHandle(request, response);
		} catch (SQLIntegrityConstraintViolationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		try {
			doHandle(request, response);
		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("안녕하세요");
		}
	}
	
	private void doHandle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLIntegrityConstraintViolationException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset = utf-8");
		PrintWriter out = response.getWriter();
		MemberDAO dao = new MemberDAO();
		
		String command = request.getParameter("command");
		
		if(command != null && command.equals("addMember")) {
			String id = request.getParameter("id");
			String pwd = request.getParameter("pwd");
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			
			MemberVO vo = new MemberVO();
			vo.setId(id);
			vo.setPwd(pwd);
			vo.setName(name);
			vo.setEmail(email);
			int num = dao.addMember(vo);
			if(num == 0) { //무결성 위반시
				response.sendRedirect("/Ch07/errorduplipage.html");
			}
		}else if(command!= null && command.equals("delMember")) {
			String id = request.getParameter("id");
			dao.delMember(id);
		}
		
		List list = dao.listMembers();
	
		
		out.print("<HTML><BODY>");
		out.print("<TABLE border = 1><tr align = 'center' bgcolor = 'lightgreen'>");
		out.print("<td> 아이디 </td><td>비밀번호</td><td>이름</td><td>이메일</td><td>가입일</td></tr>");
		
		for(int i = 0;i < list.size();i++) {
			MemberVO memberVO = (MemberVO) list.get(i);
			String id = memberVO.getId();
			String pwd = memberVO.getPwd();
			String name = memberVO.getName();
			String email = memberVO.getEmail();
			Date joinDate = memberVO.getJoinDate();
			out.print("<tr><td>" + id + "</td><td>"+
						pwd + "</td><td>"+
						name + "</td><td>"+
						email + "</td><td>"+
						joinDate + "</td></td>"+
						"<a href = '/Ch07/member?command=delMember&id=" + id + "'>삭제</a></td></tr>");
		}
		out.print("</TABLE></BODY></HTML>");
		out.print("<a href = '/Ch07/memberForm.html'>새 회원 등록하기</a>");
	
	}
	

}
