package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.MemberDto;
import service.LoginService;
import service.LoginServiceImpl;

@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doHandle(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doHandle(request,response);
	}
	

	private void doHandle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession sess = request.getSession();
		
		String path = request.getContextPath(); 
		String uri = request.getRequestURI();	
		String command = uri.substring(path.length());
		System.out.println("사용한 커맨드  : " + command);
		
	    if ("/login.do".equals(command)) {
	    	MemberDto dto = new MemberDto();
	    	LoginService login = new LoginServiceImpl();
	    	
	    	dto.setId(request.getParameter("user_id"));
	    	dto.setPw(request.getParameter("user_pw"));
	    	
	    	dto = login.execute(dto);	
	    	
	    	if(dto.getName() == null) {
//	    		response.sendRedirect("loginFail.jsp");
	    		RequestDispatcher dispatch = request.getRequestDispatcher("loginFail.jsp");
	    		dispatch.forward(request,response);
//	    		로그인 실패 페이지로 이동
	    	}else {
	    		sess.setAttribute("user_id", dto.getId());
	    		response.sendRedirect("index.jsp");
	    	}
	    	
	    	
	   	    }
	    else if ("/logout.do".equals(command)) {
	    	String id = (String) sess.getAttribute("user_id");
	    	System.out.println(id);
	    	
	   }
	}

}
