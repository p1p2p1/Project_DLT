package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;



public class MemberDao {
	private Connection con;
	private PreparedStatement stmt;
	private DataSource dataFactory;
	public static MemberDao instance;
	
	public MemberDao() {
		try {
			Context ctx = new InitialContext();
			Context envContext = (Context) ctx.lookup("java:/comp/env");
			dataFactory = (DataSource) envContext.lookup("jdbc/Oracle11g");
		}catch (Exception e) {
			e.printStackTrace();
		}
	}


	
	public static MemberDao getInstance() {
		if(instance == null) {
			instance = new MemberDao();
		}
		return instance;
	}
	
	public MemberDto checkId(MemberDto dto) {
		try {
			con = dataFactory.getConnection();		
			String query = "SELECT * FROM members WHERE ab_id = ?";				
			stmt = con.prepareStatement(query);
			String userId = dto.getId();
			String userPw = dto.getPw();
			stmt.setString(1, userId);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				String pw = rs.getString("ab_pw");
				//login success
				if(userPw.equals(pw))
				{
					String userPhone = rs.getString("ab_phone");
					String userName = rs.getString("ab_name");
					String userEmail = rs.getString("ab_email");
					Date userDate = rs.getDate("ab_rdate");
					String userAddress = rs.getString("ab_address");
					
					dto.setPhone(userPhone);
					dto.setName(userName);
					dto.setEmail(userEmail);
					dto.setDate(userDate);
					dto.setAddress(userAddress);
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return dto;
	}
}
