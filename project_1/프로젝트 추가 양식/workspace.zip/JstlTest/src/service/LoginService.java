package service;

import model.MemberDto;

public interface LoginService {
	public MemberDto execute(MemberDto dto);
}
