package service;

import model.MemberDao;
import model.MemberDto;

public class LoginServiceImpl implements LoginService{
	private MemberDao dao;
	
	public LoginServiceImpl() {
		dao = MemberDao.getInstance();
	}
	
	public MemberDto execute(MemberDto dto) {
		dao.checkId(dto);
		return dto;
	}
}
