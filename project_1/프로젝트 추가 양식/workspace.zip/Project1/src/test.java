class test {
    public int solution(int[][] land) {
        int answer = 0;
        int[] check = {};
        
        for(int i = 0;i < land[0].length;i++){
            for(int j = 0;i < land.length;j++){
                check[i] += land[i][j];
            }
            if(answer < check[i]){
                answer = check]i];
            }
        }
        
        return answer;
    }
    
    public static void main(String[] args) {
    	test test = new test();
		System.out.println(test.solution({{0, 0, 0, 1, 1, 1, 0, 0}, {0, 0, 0, 0, 1, 1, 0, 0}, {1, 1, 0, 0, 0, 1, 1, 0}, {1, 1, 1, 0, 0, 0, 0, 0}, {1, 1, 1, 0, 0, 0, 1, 1}}));
	}
}