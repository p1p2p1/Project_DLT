package com.addrbook.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.addrbook.model.AddrDao;
import com.addrbook.model.AddrDto;
import com.addrbook.service.DeleteService;
import com.addrbook.service.DeleteServicelmpl;
import com.addrbook.service.InsertService;
import com.addrbook.service.InsertServicelmpl;
import com.addrbook.service.ListService;
import com.addrbook.service.ListServicelmpl;
import com.addrbook.service.UpdateService;
import com.addrbook.service.UpdateServicelmpl;


@WebServlet("/FrontController")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("get 요청");
		actionDo(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("post 요청");
		actionDo(request, response);
	}

	private void actionDo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String uri = request.getRequestURI();
		String conPath = request.getContextPath();
		String command = uri.substring(conPath.length());
		
		System.out.println(uri);
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset = utf-8");
		
		System.out.println("커맨드 확인 : " + command);
		
		//입력 컨트롤러
		if(command.equals("/insert.do")) {
			System.out.println("insert.do");
			
			AddrDto dtoAddr = new AddrDto();
			dtoAddr.setName(request.getParameter("name"));
			dtoAddr.setEmail(request.getParameter("email"));
			dtoAddr.setComdept(request.getParameter("comdept"));
			dtoAddr.setBirth(request.getParameter("birth"));
			dtoAddr.setTel(request.getParameter("tel"));
			dtoAddr.setMemo(request.getParameter("memo"));
			
			//이름 출력 문제 없음
			InsertService insertservice = new InsertServicelmpl();
			request.setAttribute("dtoAddr", dtoAddr);
			
			//입력 서비스 실행
			int errorCode = insertservice.execute(request, response);
			System.out.println(request.getAttribute("dtoAddr"));
			
			//무결성 검사
			if(errorCode == 0) {
				response.sendRedirect("/duplicate_error.jsp");
			}
			else {
				response.sendRedirect("/list.do");
			}
		}
		
		//조회 컨트롤러
		else if(command.equals("/list.do")) {
			System.out.println("list.do");
			
			ListService listService = new ListServicelmpl();
			List<AddrDto> insAddr = new ArrayList<>();

			insAddr = (List<AddrDto>) listService.execute(request, response);
			
			request.setAttribute("addrList", insAddr);
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("/addrbook_list.jsp");
			dispatcher.forward(request, response);

		}
		
		//수정 컨트롤러
		else if(command.equals("/update.do")) {
			System.out.println("update.do");
			
			UpdateService updateService = new UpdateServicelmpl();
			
			AddrDto dtoAddr = new AddrDto();
			dtoAddr.setId(request.getParameter("id"));
			dtoAddr.setName(request.getParameter("name"));
			dtoAddr.setEmail(request.getParameter("email"));
			dtoAddr.setTel(request.getParameter("tel"));
			dtoAddr.setBirth(request.getParameter("birth"));
			dtoAddr.setComdept(request.getParameter("comdept"));
			dtoAddr.setMemo(request.getParameter("memo"));
			
			request.setAttribute("dtoAddr", dtoAddr);
			
			updateService.execute(request, response);
			response.sendRedirect("/list.do");
		}
		
		//삭제 컨트롤러
		else if(command.equals("/delete.do")) {
			System.out.println("delete.do");
			
			DeleteService deleteService = new DeleteServicelmpl();
			
			String id = request.getParameter("id");
			
			request.setAttribute("id", id);
			deleteService.execute(request, response);
			response.sendRedirect("/list.do");
		}
	}
}
