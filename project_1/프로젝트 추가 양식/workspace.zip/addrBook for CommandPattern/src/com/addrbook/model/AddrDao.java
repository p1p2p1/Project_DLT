package com.addrbook.model;

import java.sql.Connection;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;


public class AddrDao {
	private Connection con;
	private PreparedStatement stmt;
	private DataSource dataFactory;
	public static AddrDao instance;
	
	public AddrDao() {
		try {
			Context ctx = new InitialContext();
			Context envContext = (Context) ctx.lookup("java:/comp/env");
			dataFactory = (DataSource) envContext.lookup("jdbc/Oracle11g");
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static AddrDao getInstance() {
		if(instance == null) {
			instance = new AddrDao();
		}
		return instance;
	}
	
	//jspBean 사용해서 id에 해당하는 정보 읽어오기
	public AddrDto readById(int id) {
		AddrDto addrDto = new AddrDto();
		try {
			con = dataFactory.getConnection();
			String query = "SELECT * FROM addrbook WHERE ab_id = ?";
			
			
			stmt = con.prepareStatement(query);
			stmt.setInt(1, id);
			ResultSet rs = stmt.executeQuery();
			
			rs.next();
			addrDto.setName(rs.getString("ab_name"));
			addrDto.setEmail(rs.getString("ab_email"));
			addrDto.setTel(rs.getString("ab_tel"));
			addrDto.setBirth(rs.getString("ab_birth"));
			addrDto.setComdept(rs.getString("ab_comdept"));	
			addrDto.setMemo(rs.getString("ab_memo"));
			
			stmt.close();
			con.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return addrDto;
	}
	
	//주소록 조회 DAO
	public List<AddrDto> listAddr(){
		List<AddrDto> addrList = new ArrayList<>();
		
		try {
			con = dataFactory.getConnection();
			String query = "SELECT * FROM addrbook ORDER BY ab_id";
			
			stmt = con.prepareStatement(query);

			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				String id = rs.getString("ab_id");
				String name = rs.getString("ab_name");
				String email = rs.getString("ab_email");
				String tel = rs.getString("ab_tel");
				String birth = rs.getString("ab_birth");
				String comdept = rs.getString("ab_comdept");
				String memo = rs.getString("ab_memo");
				AddrDto dto  = new AddrDto();
				
				dto.setId(id);
				dto.setName(name);
				dto.setEmail(email);
				dto.setTel(tel);
				dto.setBirth(birth);
				dto.setComdept(comdept);
				dto.setMemo(memo);
				addrList.add(dto);
			}
			rs.close();
			stmt.close();
			con.close();
			
			
			stmt.close();
			con.close();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return addrList;
	}
	
	//주소록 추가 DAO
	public int insertAddr(AddrDto addr){
		try {
			con = dataFactory.getConnection();
			String query = "INSERT INTO addrbook VALUES(addr_seq.nextval, ?, ?, ?, ?, ?, ?)";
			stmt = con.prepareStatement(query);
			stmt.setString(1, addr.getName());
			stmt.setString(2, addr.getEmail());
			stmt.setString(3, addr.getComdept());
			stmt.setString(4, addr.getBirth());
			stmt.setString(5, addr.getTel());
			stmt.setString(6, addr.getMemo());
			
			stmt.executeUpdate();
			stmt.close();
			con.close();
		}catch (Exception e) {
			if(((SQLException) e).getErrorCode() == 1) {
				System.out.println("무결성 위반");
				return 0;
			}
			else {
				e.printStackTrace();
			}	
		}
		return 1;
	}
	
	public void UpdateAddr(AddrDto addr) {
		try {
			con = dataFactory.getConnection();
			//들어오는 거 확인
			String query = "UPDATE addrbook SET ab_name = ?, "
					+ "ab_email = ?, ab_comdept = ?, "
					+ "ab_birth = ?, ab_tel = ?, ab_memo = ?"
					+ "WHERE ab_id = ?";
			stmt = con.prepareStatement(query);
			
//			//SELECT id FROM addrbook;
//			if(Integer.parseInt(addr.getId())> 1) {
//				System.out.println("안녕하세요");
//				String checkIdQuery = "SELECT ID FROM addrbook";
//				stmt = con.prepareStatement(checkIdQuery);
//				
//				ResultSet rs = stmt.executeQuery();
//				
//				while(rs.next()) {
//					String[] checkId = rs.getString("id");
//					System.out.println(checkId);
//				}
//			}

			stmt.setString(1, addr.getName());
			stmt.setString(2, addr.getEmail());
			stmt.setString(3, addr.getComdept());
			stmt.setString(4, addr.getBirth());
			stmt.setString(5, addr.getTel());
			stmt.setString(6, addr.getMemo());
			stmt.setString(7, addr.getId());
			
			stmt.executeUpdate();
			stmt.close();
			con.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void DeleteAddr(String id) {
		try {
			con = dataFactory.getConnection();
			
			String query = "DELETE FROM addrbook WHERE ab_id = ?";
			
			stmt = con.prepareStatement(query);
			
			stmt.setString(1, id);
			stmt.executeUpdate();
			
			stmt.close();
			con.close();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}
