package com.addrbook.model;


public class AddrDto {
	private String id;
	private String name;
	private String email;
	private String comdept;
	private String birth;
	private String tel;
	private String memo;


	public String getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getEmail() {
		return email;
	}
	public String getComdept() {
		return comdept;
	}
	public String getBirth() {
		return birth;
	}
	public String getTel() {
		return tel;
	}
	public String getMemo() {
		return memo;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setComdept(String comdept) {
		this.comdept = comdept;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
}
