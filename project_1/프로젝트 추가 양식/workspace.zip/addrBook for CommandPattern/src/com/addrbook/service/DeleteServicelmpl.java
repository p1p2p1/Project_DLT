package com.addrbook.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.addrbook.model.AddrDao;

public class DeleteServicelmpl implements DeleteService {
	private AddrDao addrDao;
	
	public DeleteServicelmpl() {
		addrDao = AddrDao.getInstance();
	}
	

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String id = (String) request.getAttribute("id");
		
		addrDao.DeleteAddr(id);
	}
	
}
