package com.addrbook.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface InsertService {
	public int execute(HttpServletRequest request, HttpServletResponse response);
}
