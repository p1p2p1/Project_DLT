package com.addrbook.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.addrbook.model.*;

public class InsertServicelmpl implements InsertService{
	private AddrDao addrDao;
	
	public InsertServicelmpl() {
		addrDao = AddrDao.getInstance();
	}
	
	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		AddrDto dtoAddr = (AddrDto)request.getAttribute("dtoAddr");
		//null 값?
		//setAttribute() 메소드 안써서 발생
		/* System.out.println(insAddr.getName()); */
		
		//jsp name 오타로 인해 null값 반환
//		System.out.println(dtoAddr.getComdept());
		int errorCode = addrDao.insertAddr(dtoAddr);
		return errorCode;
	}

}
