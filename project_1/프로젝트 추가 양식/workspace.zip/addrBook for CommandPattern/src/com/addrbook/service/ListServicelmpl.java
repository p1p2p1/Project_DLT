package com.addrbook.service;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.addrbook.model.AddrDao;
import com.addrbook.model.AddrDto;

public class ListServicelmpl implements ListService{
	private AddrDao addrDao;
	
	public ListServicelmpl() {
		addrDao = AddrDao.getInstance();
	}
	
	@Override
	public List<AddrDto> execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		List<AddrDto> insAddr = new ArrayList<>();
		insAddr = (List<AddrDto>) addrDao.listAddr();
		return insAddr;
	}
	
	
}
