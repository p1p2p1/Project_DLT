package com.addrbook.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.addrbook.model.AddrDao;
import com.addrbook.model.AddrDto;

public class UpdateServicelmpl implements UpdateService{
	private AddrDao addrDao;
	
	public UpdateServicelmpl() {
		addrDao = AddrDao.getInstance();
	}

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		AddrDto addrDto = new AddrDto();
		addrDto = (AddrDto) request.getAttribute("dtoAddr");
		addrDao.UpdateAddr(addrDto);
	}
}
