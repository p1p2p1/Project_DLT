package ch06_01;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet("/calc")
public class CalcServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static float USD_RATE = 1124.70F;
	private static float JPY_RATE = 10.113F;
	private static float CNY_RATE = 163.30F;
	private static float GBP_RATE = 1444.35F;
	private static float EUR_RATE = 1295.97F;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset = utf-8");
		
		PrintWriter pw = response.getWriter();
		
		String command = request.getParameter("command");
		String won = request.getParameter("won");
		String operator = request.getParameter("operator");
		
		try {
			if(command != null && command.equals("calculate")) {
				String result = calculate(Float.parseFloat(won),operator);
				pw.print("<html><font size = 10>변환결과</font><br>");
				pw.print("<html><font size = 10>" + result + "</font><br>");
				pw.print("<a href = '/ch06/calc'>환율 계산기</a>");
			}
			
			else{
				pw.print("<html><title>환율계산기</title>");
				pw.print("<font size = 5>환율 계산기 </font><br>");
				pw.print("<form name = 'frmCalc' method = 'get' action = '/ch06/calc'/>");
				pw.print("원화 : <input type = 'text' name = 'won' size = 10/>");
				pw.print("<select name = 'operator'>");
				pw.print("<option value = 'dollar'>달러</option>");
				pw.print("<option value = 'en'>엔화</option>");
				pw.print("<option value = 'wian'>위안</option>");
				pw.print("<option value = 'pound'>파운드</option>");
				pw.print("<option value = 'euro'>유로</option>");
				pw.print("</select>");
				pw.print("<input type = 'hidden' name = 'command' value = 'calculate' />");
				pw.println("<input type = 'submit' value = '변환' />");
				pw.println("</form>");
				pw.print("</html>");
				pw.close();
			}

		} catch(NumberFormatException e) {
			pw.println("<html>폼 태그에 숫자 값을 입력해주세요. <br>");
			pw.print("<a href = '/ch06/calc'>환율 계산기로 이동</a>");
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	public static String calculate(float won, String operator) {
		String result = null;
		if(operator.equals("dollar")) { //미국
			result = String.format("%.6f", won / USD_RATE);
		}
		else if(operator.equals("en")) { //일본
			result = String.format("%.6f", won / JPY_RATE);
		}
		else if(operator.equals("wian")) { //중국
			result = String.format("%.6f", won / CNY_RATE);
		}
		else if(operator.equals("pound")) { //영국
			result = String.format("%.6f", won / GBP_RATE);
		}
		else if(operator.equals("euro")) { //유럽
			result = String.format("%.6f", won / EUR_RATE);
		}
		
		return result;
	}

}


